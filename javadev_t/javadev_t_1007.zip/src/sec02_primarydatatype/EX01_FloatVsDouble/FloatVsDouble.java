package sec02_primarydatatype.EX01_FloatVsDouble;

public class FloatVsDouble {

}
