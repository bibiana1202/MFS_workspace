package sec01_datatype.EX01_UsageOfDataType;

public class UsageOfDataType {
	public static void main(String[] args) {
		// 변수 선언과 함께 값 대입
		int 뷁 = 3;
		// 변수 선언과 값 대입 분리
		
		int b;
		b = 4;
		System.out.println(뷁);
		System.out.println(b);
	}
}
