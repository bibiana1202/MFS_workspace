package basic;

public class OpTest17 {
	public static void main(String[] args) {
		
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);
		System.out.println((int)(Math.random()*6)+1);

	}
}
