package basic;

public class OpTest11 {
	public static void main(String[] args) {
		int a = 5;
		a += 2; //a = a + 2;
		System.out.println("a =" + a);
		a -= 2; //a = a - 2;
		System.out.println("a =" + a);
		a *= 2; //a = a * 2;
		System.out.println("a =" + a);
		a /= 2; //a = a / 2;
		System.out.println("a =" + a);
		a %= 2; //a = a % 2;
		System.out.println("a =" + a);
	}
}
