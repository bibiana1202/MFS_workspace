package oop7;

public class Triangle extends Shape {
	int w = 10;
	int h = 5;
	void area() {
		res = w * h / 2;
	}
}
