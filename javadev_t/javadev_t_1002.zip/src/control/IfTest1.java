package control;

public class IfTest1 {
	public static void main(String[] args) {
		int n = 1;
		
		if (n==1) {
			System.out.println("M");
		} else {
			System.out.println("F");
		}
		System.out.println("종료");
	}
}
