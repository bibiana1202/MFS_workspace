package basic;

public class OpTest4 {
	public static void main(String[] args) {
		// eXcusive OR : 입력이 서로 달라야 결과가 true
		System.out.println(true ^ true);
		System.out.println(true ^ false);
		System.out.println(false ^ true);
		System.out.println(false ^ false);
		
	}
}
