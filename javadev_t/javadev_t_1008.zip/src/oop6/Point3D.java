package oop6;

public class Point3D extends Point2D {
	int z;
}
