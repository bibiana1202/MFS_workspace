package oop7;

public class Rectangle extends Shape {
	int w = 10;
	int h = 5;
	void area() {
		res = w * h;
	}
}
