package oop10;

public interface Speaker {
	public void soundUp();
	public void soundDown();
}
