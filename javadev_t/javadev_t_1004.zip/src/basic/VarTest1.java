package basic;

public class VarTest1 {
	public static void main(String[] args) {
		int a = 10;
		a = 5;
		
		int b;
		b = 10;
		
		
		
	}
}
