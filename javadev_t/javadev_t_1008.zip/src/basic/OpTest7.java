package basic;

public class OpTest7 {
	public static void main(String[] args) {
		int a = 10;
		int b = 6;
		
		System.out.println(a & b);  // bit and 연산
		System.out.println(a | b);  // bit or
	}
}
