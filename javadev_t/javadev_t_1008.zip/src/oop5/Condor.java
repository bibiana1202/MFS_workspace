package oop5;

public class Condor extends Bird {
	@Override
	public String toString() {
		return "Condor 입니다.";
	}
}
