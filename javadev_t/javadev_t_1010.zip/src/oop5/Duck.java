package oop5;

public class Duck extends Bird {
	@Override
	public String toString() {
		return "Duck 입니다";
	}
}
