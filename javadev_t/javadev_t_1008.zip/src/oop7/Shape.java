package oop7;

public class Shape {
	double res;
	void area() {}
}
