package basic;

public class OpTest12 {
	public static void main(String[] args) {
		int a = 10;
		
		System.out.println(a << 2);
	}
}
