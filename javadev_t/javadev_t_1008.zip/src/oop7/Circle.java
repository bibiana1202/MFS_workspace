package oop7;

public class Circle extends Shape {
	int r = 10;
	void area() {
		res = r*r*3.14;
	}
}
