package basic;

public class OpTest13 {
	public static void main(String[] args) {
		int n = 10;

		System.out.println( n == 1 ? "남자" : 
							n == 2 ? "여자" : 
								     "에러");
		System.out.println("종료");
	}
}
