package basic;

public class OpTest8 {
	public static void main(String[] args) {
		int a = 5;
		
		a++; // a = a + 1;
		System.out.println("a =" + a);
		
		++a; // a = a + 1;
		System.out.println("a =" + a);
	}
}
