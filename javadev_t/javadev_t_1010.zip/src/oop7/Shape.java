package oop7;

public abstract class Shape {
	double res;
	abstract void area();
}
