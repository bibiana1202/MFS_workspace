package oop3;

public class Dice {
	public int getNumber() {
		return (int)(Math.random() * 6 + 1);
	}
}
