package basic;

public class OpTest18 {
	public static void main(String[] args) {
		
		System.out.println((int)(Math.random() * 12)+4);

	}
}
