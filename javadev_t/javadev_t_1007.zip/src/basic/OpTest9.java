package basic;

public class OpTest9 {
	public static void main(String[] args) {
		int a = 5;
		int t;
		t = a--; // t = a;
		         // a = a - 1;
		System.out.println("a =" + a);
		System.out.println("t =" + t);
	
	}
}
