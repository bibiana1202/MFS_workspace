package control;

public class ForTest2 {
	public static void main(String[] args) {
		for(int i = 10; i <= 30; i+=10) {
			System.out.println(i + ":안녕하세요");
		}
		System.out.println("종료");
	}
}
