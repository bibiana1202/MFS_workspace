package oop5;

public class Bird extends Animal {
	@Override
	public String toString() {
		return "Bird 입니다.";
	}
}
