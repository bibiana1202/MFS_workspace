package basic.imsi;

public class Hello3 {
	public static void main(String[] args) {
		System.out.println("안녕하세요~");
		
		System.out.printf("%4.2f",23.141592);
		System.out.println();
		
	}
}
