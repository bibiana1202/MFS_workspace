package basic;

public class OpTest10 {
	public static void main(String[] args) {
		int a = 5;
		int t;
		t = --a; // a = a - 1;
		         // t = a;
		System.out.println("a =" + a);
		System.out.println("t =" + t);
	
	}
}
