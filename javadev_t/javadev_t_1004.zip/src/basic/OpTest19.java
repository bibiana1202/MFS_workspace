package basic;

public class OpTest19 {
	public static void main(String[] args) {

		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);
		System.out.println(((int) (Math.random() * 18) + 6) * 100);

	}
}
