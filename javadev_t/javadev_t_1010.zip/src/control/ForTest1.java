package control;

public class ForTest1 {
	public static void main(String[] args) {

		for( ; ; ) {
			if (false) break;
			int i=7;
			System.out.println(i + ":새싹");
		}
		System.out.println("종료");
	}
}
