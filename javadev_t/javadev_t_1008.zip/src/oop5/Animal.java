package oop5;

public class Animal {

	@Override
	public String toString() {
		return "Animal 입니다.";
	}
}
